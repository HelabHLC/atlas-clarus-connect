(function(global){
  'use strict';
  const enc=new TextEncoder();
  function u16(value){return [(value>>>8)&255,value&255]}
  function u32(value){return [(value>>>24)&255,(value>>>16)&255,(value>>>8)&255,value&255]}
  function f32(value){const b=new ArrayBuffer(4);new DataView(b).setFloat32(0,value,false);return Array.from(new Uint8Array(b))}
  function utf16be(value){const out=[];for(const ch of value){const code=ch.codePointAt(0);if(code<=65535)out.push(...u16(code));else{const v=code-65536;out.push(...u16(0xD800+(v>>10)),...u16(0xDC00+(v&1023)))}}out.push(0,0);return out}
  function ase(palette){const blocks=[];palette.forEach(c=>{const name=utf16be(c.ref),body=[...u16(name.length/2),...name,...enc.encode('RGB '),...f32(c.rgb[0]/255),...f32(c.rgb[1]/255),...f32(c.rgb[2]/255),0,0];blocks.push(...u16(1),...u32(body.length),...body)});return new Uint8Array([...enc.encode('ASEF'),0,1,0,0,...u32(palette.length),...blocks])}
  function readAse(bytes){const d=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);if(String.fromCharCode(...bytes.slice(0,4))!=='ASEF')throw Error('Invalid ASE header');let p=12;const count=d.getUint32(8,false),out=[];for(let n=0;n<count;n++){const type=d.getUint16(p,false),len=d.getUint32(p+2,false),end=p+6+len;p+=6;if(type===1){const chars=d.getUint16(p,false);p+=2;let name='';for(let i=0;i<chars-1;i++){name+=String.fromCharCode(d.getUint16(p,false));p+=2}p+=2;const model=String.fromCharCode(...bytes.slice(p,p+4));p+=4;if(model==='RGB '){out.push({ref:name,rgb:[d.getFloat32(p,false),d.getFloat32(p+4,false),d.getFloat32(p+8,false)].map(v=>Math.round(v*255))})}}p=end}return out}
  function slug(ref){return ref.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')}
  function tokens(palette,master,name='ATLAS Clarus Palette'){const color={};palette.forEach(c=>{color[c.ref]={$type:'color',$value:c.hex,$extensions:{'org.atlas-clarus':{atlas_row_id:c.id,master_sha256:master,rgb:c.rgb,lab:c.lab,freeze_status:'FROZEN'}}}});return {$schema:'https://tr.designtokens.org/format/',$description:`${name} — ATLAS Clarus, Figma-compatible design tokens`,color}}
  function css(palette,master,name='ATLAS Clarus Palette'){return `/* ${name}\n   ATLAS Clarus · Master SHA-256: ${master}\n   Frozen reference identities; not measured QC.\n*/\n:root {\n${palette.map(c=>`  --atlas-${slug(c.ref)}: ${c.hex}; /* row ${c.id} · RGB ${c.rgb.join('/')} */`).join('\n')}\n}\n`}
  function gpl(palette,master,name='ATLAS Clarus Palette'){return `GIMP Palette\nName: ${name.replace(/[\r\n]/g,' ')}\nColumns: 4\n# Master SHA-256: ${master}\n# Frozen reference identities; not measured QC.\n${palette.map(c=>`${String(c.rgb[0]).padStart(3)} ${String(c.rgb[1]).padStart(3)} ${String(c.rgb[2]).padStart(3)}\t${c.ref}`).join('\n')}\n`}
  function clarus(palette,master,name='ATLAS Clarus Palette'){return {format:'ATLAS_CLARUS_PALETTE',version:'1.1',palette_name:name,workflow:'ATLAS Clarus v3.4.0',master_sha256:master,row_id_base:0,freeze_status:'FROZEN',measured_qc_status:'NOT_MEASURED',references:palette.map((c,index)=>({palette_index:index,atlas_row_id:c.id,reference:c.ref,master_rgb:c.rgb,master_hex:c.hex,master_lab:c.lab}))}}
  // Validate the entire file before the caller changes any workspace state.
  // IDs and channels are numbers in our own exports: never coerce null,
  // booleans, strings or arrays into a different reference identity.
  function validateClarus(data,colors,master){
    if(!data||data.format!=='ATLAS_CLARUS_PALETTE'||
       !['1.0','1.1'].includes(data.version)||data.row_id_base!==0||
       data.master_sha256!==master||data.freeze_status!=='FROZEN'||
       data.measured_qc_status!=='NOT_MEASURED'||
       (data.palette_name!==undefined&&typeof data.palette_name!=='string')||
       !Array.isArray(data.references)||!data.references.length||data.references.length>64){
      throw Error('Not a compatible Clarus palette or master.');
    }
    const masterById=new Map(colors.map(c=>[c.id,c])),seen=new Set(),ids=[];
    for(const ref of data.references){
      const c=ref&&Number.isInteger(ref.atlas_row_id)&&masterById.get(ref.atlas_row_id);
      if(!c||seen.has(c.id)||ref.reference!==c.ref||
         typeof ref.master_hex!=='string'||ref.master_hex.toUpperCase()!==c.hex.toUpperCase()||
         !Array.isArray(ref.master_rgb)||ref.master_rgb.length!==3||
         !c.rgb.every((v,i)=>Number.isInteger(ref.master_rgb[i])&&v===ref.master_rgb[i])){
        throw Error('Identity validation failed.');
      }
      seen.add(c.id);ids.push(c.id);
    }
    return ids;
  }
  global.ATLAS_CLARUS_EXPORTS={ase,readAse,tokens,css,gpl,clarus,validateClarus};
})(typeof window!=='undefined'?window:globalThis);
