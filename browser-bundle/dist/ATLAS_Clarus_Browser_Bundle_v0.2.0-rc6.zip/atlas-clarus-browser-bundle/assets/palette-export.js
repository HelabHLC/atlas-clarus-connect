(function(global){
  'use strict';
  const enc=new TextEncoder();
  function u16(value){return [(value>>>8)&255,value&255]}
  function u32(value){return [(value>>>24)&255,(value>>>16)&255,(value>>>8)&255,value&255]}
  function f32(value){const b=new ArrayBuffer(4);new DataView(b).setFloat32(0,value,false);return Array.from(new Uint8Array(b))}
  function utf16be(value){const out=[];for(const ch of value){const code=ch.codePointAt(0);if(code<=65535)out.push(...u16(code));else{const v=code-65536;out.push(...u16(0xD800+(v>>10)),...u16(0xDC00+(v&1023)))}}out.push(0,0);return out}
  function ase(palette){const blocks=[];palette.forEach(c=>{const name=utf16be(c.ref),body=[...u16(name.length/2),...name,...enc.encode('RGB '),...f32(c.rgb[0]/255),...f32(c.rgb[1]/255),...f32(c.rgb[2]/255),0,0];blocks.push(...u16(1),...u32(body.length),...body)});return new Uint8Array([...enc.encode('ASEF'),0,1,0,0,...u32(palette.length),...blocks])}
  function readAse(bytes){const d=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);if(String.fromCharCode(...bytes.slice(0,4))!=='ASEF')throw Error('Invalid ASE header');let p=12;const count=d.getUint32(8,false),out=[];for(let n=0;n<count;n++){const type=d.getUint16(p,false),len=d.getUint32(p+2,false),end=p+6+len;p+=6;if(type===1){const chars=d.getUint16(p,false);p+=2;let name='';for(let i=0;i<chars-1;i++){name+=String.fromCharCode(d.getUint16(p,false));p+=2}p+=2;const model=String.fromCharCode(...bytes.slice(p,p+4));p+=4;if(model==='RGB '){out.push({ref:name,rgb:[d.getFloat32(p,false),d.getFloat32(p+4,false),d.getFloat32(p+8,false)].map(v=>Math.round(v*255))})}}p=end}return out}
  function slug(ref){return ref.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')}
  function tokens(palette,master){const color={};palette.forEach(c=>{color[c.ref]={$type:'color',$value:c.hex,$extensions:{'org.atlas-clarus':{atlas_row_id:c.id,master_sha256:master,rgb:c.rgb,lab:c.lab,freeze_status:'FROZEN'}}}});return {$schema:'https://tr.designtokens.org/format/',$description:'ATLAS Clarus palette — Figma-compatible design tokens',color}}
  function css(palette,master){return `/* ATLAS Clarus palette\n   Master SHA-256: ${master}\n   Frozen reference identities; not measured QC.\n*/\n:root {\n${palette.map(c=>`  --atlas-${slug(c.ref)}: ${c.hex}; /* row ${c.id} · RGB ${c.rgb.join('/')} */`).join('\n')}\n}\n`}
  function clarus(palette,master){return {format:'ATLAS_CLARUS_PALETTE',version:'1.0',workflow:'ATLAS Clarus v3.4.0',master_sha256:master,row_id_base:0,freeze_status:'FROZEN',measured_qc_status:'NOT_MEASURED',references:palette.map((c,index)=>({palette_index:index,atlas_row_id:c.id,reference:c.ref,master_rgb:c.rgb,master_hex:c.hex,master_lab:c.lab}))}}
  global.ATLAS_CLARUS_EXPORTS={ase,readAse,tokens,css,clarus};
})(typeof window!=='undefined'?window:globalThis);
