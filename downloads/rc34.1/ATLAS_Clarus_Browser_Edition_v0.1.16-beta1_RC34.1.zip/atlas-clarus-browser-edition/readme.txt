ATLAS Clarus Browser Edition 0.1.16-beta1
Tool Exchange RC34.1 public beta candidate.
Upload this ZIP intact and replace the existing plugin. Then Tools > ATLAS Clarus Browser Edition > Mitgeliefertes RC34.1 prüfen und aktiv schalten. Updating the plugin alone preserves the active runtime. Export all open work first. Previous runtime retained for rollback. Recipe imports restore stored computational results; no editable search-session or physical recipe validation is claimed.
