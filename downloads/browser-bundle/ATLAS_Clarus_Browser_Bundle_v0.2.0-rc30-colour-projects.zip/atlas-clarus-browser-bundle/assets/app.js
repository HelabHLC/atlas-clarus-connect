(function(){
  'use strict';
  const MASTER='8283ab91b10f89ac758d09ecf5fb4d6343536600a06dd468b1cc1ecf4ec747c4';
  const doc=window.ATLAS_CLARUS_DATA||{};
  const colors=doc.colors||[];
  const libraryViews=doc.views||{};
  let designerLayer=null;
  try{designerLayer=window.ATLAS_CLARUS_DESIGNER.bind(window.ATLAS_CLARUS_DESIGNER_DATA,colors,doc.master_sha256)}catch(_){/* Fail closed: retain the unchanged PKL-only UI. */}
  let nameSearchById=new Map();
  try{const n=window.ATLAS_CLARUS_NAME_SEARCH_DATA;if(n.schema!=='ATLAS_CLARUS_NAME_SEARCH_INDEX'||n.master_sha256!==MASTER||n.entry_count!==13283||n.records.length!==13283)throw Error('Name Search Index rejected');nameSearchById=new Map(n.records.map(r=>[Number(r.i),r]));if(nameSearchById.size!==13283||colors.some(c=>nameSearchById.get(c.id)?.r!==c.ref))throw Error('Name Search Index binding failed')}catch(_){nameSearchById=new Map()}
  if(designerLayer&&nameSearchById.size===13283){for(const c of colors){const d=window.ATLAS_CLARUS_DESIGNER.get(designerLayer,c),n=nameSearchById.get(c.id);designerLayer.byId.set(c.id,Object.freeze({...d,designer_name_en:n.d,display_name:`${n.d} · ${c.ref}`,family_name_en:n.f,tone_system_version:'0.1',naming_layer_version:'0.3.0'}))}}
  let printWorkspace=null,referenceCardWorkspace=null;
  let recipeStore=null;
  try{recipeStore=window.ATLAS_CLARUS_RECIPES.create(window.ATLAS_BASIS23_DATA,colors,doc.master_sha256)}catch(_){/* Fail closed for recipes; retain the reference workflow. */}
  let acmsStore=null;
  try{acmsStore=window.ATLAS_ACMS_RECIPES.create(window.ATLAS_ACMS_DATA,colors,doc.master_sha256,libraryViews)}catch(_){/* Fail closed for ACMS. */}
  let selectedAssignment=null;
  let selected=colors.find(c=>c.id===4665)||colors[0]; let arbeReference=null; let palette=[],palettes=[],activePaletteId='';
  let filtered=colors.slice(); let page=0; let activeView='core'; const perPage=96;
  const $=s=>document.querySelector(s);
  const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const views=[...document.querySelectorAll('.view')];
  let hoverReturn=null,pickerReturn=false;
  function route(){
    const requested=(location.hash||'#picker').slice(1),id=views.some(v=>v.id===requested)?requested:'picker';
    const previous=views.find(v=>v.classList.contains('active'))?.id;
    if(previous==='library'&&id==='wheel')hoverReturn={x:scrollX,y:scrollY};
    const restore=previous==='wheel'&&id==='library'?hoverReturn:null;
    if(id!=='wheel')hoverReturn=null;
    views.forEach(v=>v.classList.toggle('active',v.id===id));
    document.querySelectorAll('[data-back-hover]').forEach(b=>b.hidden=!hoverReturn);
    if(id==='wheel')drawWheel();if(id==='appearance')drawSimulation();
    // Native hash scrolling may run after this listener. Move on the next frame
    // so a newly activated view cannot start beneath the sticky header.
    requestAnimationFrame(()=>scrollTo({left:restore?.x||0,top:restore?.y||0,behavior:'instant'}));
  }
  addEventListener('hashchange',route);
  const menuToggle=$('#menu-toggle'),primaryNav=$('#primary-nav');
  function closeMenu(){primaryNav.classList.remove('open');menuToggle.setAttribute('aria-expanded','false');menuToggle.setAttribute('aria-label','Open navigation')}
  menuToggle.onclick=e=>{e.stopPropagation();const open=!primaryNav.classList.contains('open');primaryNav.classList.toggle('open',open);menuToggle.setAttribute('aria-expanded',String(open));menuToggle.setAttribute('aria-label',open?'Close navigation':'Open navigation')};
  primaryNav.querySelectorAll('a').forEach(a=>a.onclick=closeMenu);document.addEventListener('click',e=>{if(!primaryNav.contains(e.target)&&e.target!==menuToggle)closeMenu()});document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMenu()});
  function luminance(rgb){return .2126*rgb[0]+.7152*rgb[1]+.0722*rgb[2]}
  function chromaLabel(c){const match=c.ref.match(/_C(\d+)$/);return match?`C${Number(match[1])}`:'C–'}
  function sourceDescription(r){
    return `${r.source_hex} → ${r.reference_hex} · d²RGB ${r.distance_squared} · ${r.sampling.mode} · X${r.sampling.centre[0]} Y${r.sampling.centre[1]}`;
  }
  function selectedSourceHtml(c){
    const r=selectedAssignment;
    if(!r||r.atlas_row_id!==c.id)return '';
    return `<section class="source-provenance"><b>Source → reference</b><p>${esc(sourceDescription(r))}</p><small>Browser-decoded sRGB · 8 bits/channel · ${esc(r.image.name)}. Original RGB is retained when added to a palette.</small></section>`;
  }
  function paletteSourcesHtml(c,p){
    const sources=(p.sourceAssignments||[]).filter(r=>r.atlas_row_id===c.id);
    if(!sources.length)return '<small class="drawer-source-records">Original source not recorded.</small>';
    return `<details class="drawer-source-records"><summary>${sources.length} recorded source assignment${sources.length===1?'':'s'}</summary><ul>${sources.map(r=>`<li>${esc(sourceDescription(r))}<br><small>${esc(r.image.name)} · ${r.image.width} × ${r.image.height} · sRGB / 8-bit<br>File SHA-256: ${esc(r.image.sha256||'unavailable')}<br>Workflow: ${esc(r.workflow)}</small></li>`).join('')}</ul><small>Unsigned provenance. Clarus JSON preserves these records.</small></details>`;
  }
  function selectedHtml(c,wheel=false){const d=window.ATLAS_CLARUS_DESIGNER?.get(designerLayer,c),n=nameSearchById.get(c.id);const names=d?`<p class="eyebrow">ATLAS NAMES v0.3.0</p><h2>${esc(n?.d||d.designer_name_en)}</h2><div class="designer-traits">${[n?.f||d.colour_family,d.temperature,d.lightness_character,d.chroma_character].filter(Boolean).map(x=>`<span>${esc(x)}</span>`).join('')}</div>`:`<p class="eyebrow">FROZEN REFERENCE IDENTITY</p><h2>${esc(n?.d||c.ref)}</h2>`;return `<div class="selected-swatch" style="background:${esc(c.hex)}"></div>${names}<dl><dt>Exact PKL identity</dt><dd>${esc(c.ref)}</dd><dt>atlas_row_id</dt><dd>${c.id}</dd><dt>Human row</dt><dd>${c.id+1}</dd><dt>RGB</dt><dd>${c.rgb.join(' / ')}</dd><dt>HEX</dt><dd>${esc(c.hex)}</dd><dt>CIELAB</dt><dd>${c.lab.map(n=>Number(n).toFixed(2)).join(' / ')}</dd><dt>Master</dt><dd>verified metadata</dd></dl>${d?`<div class="designer-roles"><b>Suggested roles</b><p>${d.suggested_roles.map(esc).join(' · ')}</p></div>`:''}${selectedSourceHtml(c)}<div class="selection-actions"><button data-add-palette>Add to palette</button>${wheel?'<button data-back-hover'+(hoverReturn?'':' hidden')+'>← Zurück zum Hover</button>':'<button data-open-wheel>Open in Wheel</button>'}${!wheel&&pickerReturn?'<button data-back-picker>← Back to Image Picker</button>':''}<button data-reference-card>Create reference card</button><button data-prepare-print>Prepare for print</button><button data-copy>Copy identity</button></div>`}
  function select(c,assignment=null){selectedAssignment=assignment;selected=c;const solidView=activeView==='solid_c'||activeView==='solid_u';const recipeHtml=solidView?(window.ATLAS_ACMS_RECIPES?window.ATLAS_ACMS_RECIPES.render(acmsStore,c,activeView):'<p>ACMS module unavailable. Reference identity unchanged.</p>'):(window.ATLAS_CLARUS_RECIPES?window.ATLAS_CLARUS_RECIPES.render(recipeStore,c):'<p>Recipe module unavailable. Reference identity unchanged.</p>');$('#selection').innerHTML=selectedHtml(c)+recipeHtml;$('#wheel-selection').innerHTML=selectedHtml(c,true)+recipeHtml;document.querySelectorAll('[data-add-palette]').forEach(b=>b.onclick=()=>addPalette(c));document.querySelectorAll('[data-open-wheel]').forEach(b=>b.onclick=()=>{location.hash='wheel'});document.querySelectorAll('[data-back-hover]').forEach(b=>b.onclick=()=>{location.hash='library'});document.querySelectorAll('[data-back-picker]').forEach(b=>b.onclick=()=>{location.hash='picker'});document.querySelectorAll('[data-reference-card]').forEach(b=>b.onclick=()=>referenceCardWorkspace?.open(c));document.querySelectorAll('[data-prepare-print]').forEach(b=>b.onclick=()=>printWorkspace?.open('selected'));document.querySelectorAll('[data-copy]').forEach(b=>b.onclick=()=>copy(`${c.ref} | ${c.hex} | atlas_row_id ${c.id} | master_sha256 ${MASTER}`));document.querySelectorAll('[data-recipe-png]').forEach(b=>b.onclick=()=>window.ATLAS_CLARUS_RECIPES.download(recipeStore,c));document.querySelectorAll('[data-recipe-pdf]').forEach(b=>b.onclick=()=>window.ATLAS_CLARUS_RECIPES.downloadPdf(recipeStore,c));document.querySelectorAll('[data-acms-png]').forEach(b=>b.onclick=()=>window.ATLAS_ACMS_RECIPES.download(acmsStore,c,activeView,Number(b.dataset.acmsPng)));drawSimulation();renderWheelCards()}
  async function copy(s){try{await navigator.clipboard.writeText(s)}catch(_){const t=document.createElement('textarea');t.value=s;document.body.append(t);t.select();document.execCommand('copy');t.remove()}}
  function render(){const start=page*perPage;const rows=filtered.slice(start,start+perPage);$('#colour-grid').innerHTML='';rows.forEach(c=>{const n=nameSearchById.get(c.id),b=document.createElement('button');b.className='colour-card'+(luminance(c.rgb)>165?' dark-text':'');b.style.setProperty('--swatch',c.hex);b.innerHTML=`<b>${esc(n?.d||c.ref)}</b><span class="colour-card__chroma">${esc(chromaLabel(c))}</span><small>${n?esc(c.ref)+' · ':''}${esc(c.hex)} · ID ${c.id}</small>`;b.onclick=()=>select(c);$('#colour-grid').append(b)});const pages=Math.max(1,Math.ceil(filtered.length/perPage)),view=libraryViews[activeView];$('#library-status').innerHTML=`<b>${esc(view?.name||'HLC Core Reference')}</b> · ${esc(view?.status||'EXACT_ATLAS')} · ${filtered.length.toLocaleString('en')} shown · source observations ${(view?.ids?.length||colors.length).toLocaleString('en')} · master ${MASTER.slice(0,12)}…`;$('#page-info').textContent=`Page ${page+1} / ${pages}`;$('#prev-page').disabled=page===0;$('#next-page').disabled=page>=pages-1}
   function filter(){const q=$('#search').value.trim().toUpperCase(),l=$('#lightness').value,view=libraryViews[activeView],allowed=new Set((view?.ids||colors.map(c=>c.id)).map(Number));filtered=colors.filter(c=>{const n=nameSearchById.get(c.id),nameText=n?[n.d,n.f,...(n.t||[])].join(' ').toUpperCase():'';return allowed.has(c.id)&&(l==='all'||Math.round(c.lab[0])===Number(l))&&(!q||c.ref.includes(q)||c.hex.toUpperCase().includes(q)||String(c.id)===q||nameText.includes(q))});page=0;render()}
  for(let l=5;l<=95;l+=5){const o=document.createElement('option');o.value=l;o.textContent=`L* ${String(l).padStart(3,'0')}`;$('#lightness').append(o)}
  Object.entries(libraryViews).forEach(([key,v])=>{const o=document.createElement('option');o.value=key;o.textContent=v.name;$('#library-view').append(o)});$('#library-view').onchange=()=>{activeView=$('#library-view').value;filter();if(filtered.length)select(filtered.find(c=>c.id===selected?.id)||filtered[0])};$('#search').oninput=filter;$('#lightness').onchange=filter;$('#clear-search').onclick=()=>{$('#search').value='';$('#lightness').value='all';filter()};$('#prev-page').onclick=()=>{page--;render()};$('#next-page').onclick=()=>{page++;render()};
  const pickerCanvas=$('#picker-canvas'),pickerContext=pickerCanvas.getContext('2d'),pickerLoupe=$('#picker-loupe'),loupeContext=pickerLoupe.getContext('2d'),pickerSource=document.createElement('canvas'),sourceContext=pickerSource.getContext('2d',{willReadFrequently:true,colorSpace:'srgb'}),pickerSampleSize=$('#picker-sample-size');let pickerImage=null,pickerDraw=null,pickerPixels=null,pickerFileName='Image Picker image',pickerImageMeta=null,pickerLoadSequence=0;
  function drawPickerImage(){const w=pickerCanvas.width,h=pickerCanvas.height;pickerContext.clearRect(0,0,w,h);if(!pickerImage)return;const scale=Math.min(w/pickerImage.naturalWidth,h/pickerImage.naturalHeight),dw=pickerImage.naturalWidth*scale,dh=pickerImage.naturalHeight*scale,dx=(w-dw)/2,dy=(h-dh)/2;pickerContext.imageSmoothingEnabled=true;pickerContext.drawImage(pickerImage,dx,dy,dw,dh);pickerDraw={dx,dy,dw,dh,scale};}
  function pickerPoint(e){if(!pickerImage||!pickerDraw)return null;const rect=pickerCanvas.getBoundingClientRect(),x=(e.clientX-rect.left)*pickerCanvas.width/rect.width,y=(e.clientY-rect.top)*pickerCanvas.height/rect.height;if(x<pickerDraw.dx||x>=pickerDraw.dx+pickerDraw.dw||y<pickerDraw.dy||y>=pickerDraw.dy+pickerDraw.dh)return null;return {ix:Math.max(0,Math.min(pickerSource.width-1,Math.floor((x-pickerDraw.dx)/pickerDraw.scale))),iy:Math.max(0,Math.min(pickerSource.height-1,Math.floor((y-pickerDraw.dy)/pickerDraw.scale))),clientX:e.clientX,clientY:e.clientY};}
  function sampleAt(point,size){return window.ATLAS_CLARUS_SAMPLING.sampleRgba(pickerPixels,pickerSource.width,pickerSource.height,point.ix,point.iy,size)}
  function drawLoupe(point){if(!point){pickerLoupe.classList.remove('visible');return}const size=Number(pickerSampleSize.value),sample=sampleAt(point,size);if(!sample){pickerLoupe.classList.remove('visible');return}const stage=pickerCanvas.parentElement.getBoundingClientRect(),span=Math.max(11,size),half=Math.floor(span/2),cell=220/span;loupeContext.clearRect(0,0,220,250);loupeContext.imageSmoothingEnabled=false;loupeContext.drawImage(pickerSource,point.ix-half,point.iy-half,span,span,0,0,220,220);loupeContext.strokeStyle='rgba(255,255,255,.42)';loupeContext.lineWidth=1;for(let n=0;n<=span;n++){const p=n*cell;loupeContext.beginPath();loupeContext.moveTo(p,0);loupeContext.lineTo(p,220);loupeContext.stroke();loupeContext.beginPath();loupeContext.moveTo(0,p);loupeContext.lineTo(220,p);loupeContext.stroke()}const box=(span-size)/2*cell;loupeContext.strokeStyle='#9bff55';loupeContext.lineWidth=4;loupeContext.strokeRect(box+2,box+2,size*cell-4,size*cell-4);loupeContext.fillStyle='#05080c';loupeContext.fillRect(0,220,220,30);loupeContext.fillStyle='#fff';loupeContext.font='bold 10px monospace';loupeContext.fillText(size===1?`X${point.ix} Y${point.iy} RGB ${sample.rgb.join('/')}`:`${size}x${size} MEAN ${sample.rgb.join('/')}`,7,240);const localX=point.clientX-stage.left,localY=point.clientY-stage.top,left=localX+238>stage.width?localX-230:localX+14,top=localY+264>stage.height?localY-258:localY+14;pickerLoupe.style.left=Math.max(4,left)+'px';pickerLoupe.style.top=Math.max(4,top)+'px';pickerLoupe.classList.add('visible');}
  $('#picker-file').onchange=e=>{
    const file=e.target.files&&e.target.files[0];if(!file)return;
    if(!/^image\/(png|jpeg|webp|gif)$/.test(file.type)){e.target.value='';$('#picker-result').innerHTML='<p>Unsupported image type.</p>';return}
    const sequence=++pickerLoadSequence,url=URL.createObjectURL(file),image=new Image();
    if(pickerImage?.objectUrl)URL.revokeObjectURL(pickerImage.objectUrl);
    pickerImage=null;pickerPixels=null;pickerDraw=null;pickerImageMeta=null;select(selected);
    pickerContext.clearRect(0,0,pickerCanvas.width,pickerCanvas.height);
    $('#picker-result').innerHTML='<p>Loading image and recording its source hash…</p>';
    const digest=(async()=>{try{const bytes=await file.arrayBuffer();const hash=await crypto.subtle.digest('SHA-256',bytes);return Array.from(new Uint8Array(hash),b=>b.toString(16).padStart(2,'0')).join('')}catch(_){return null}})();
    image.onload=async()=>{
      const sha256=await digest;
      if(sequence!==pickerLoadSequence){URL.revokeObjectURL(url);return}
      image.objectUrl=url;pickerImage=image;pickerFileName=file.name;
      pickerSource.width=image.naturalWidth;pickerSource.height=image.naturalHeight;
      pickerImageMeta={name:file.name,width:pickerSource.width,height:pickerSource.height,sha256};
      sourceContext.drawImage(image,0,0);
      pickerPixels=sourceContext.getImageData(0,0,pickerSource.width,pickerSource.height).data;
      drawPickerImage();window.dispatchEvent(new Event('atlas-picker-image-loaded'));
      $('#picker-result').innerHTML='<p>Image ready. Move the loupe over the image and click its marked centre pixel.</p>';
    };
    image.onerror=()=>{URL.revokeObjectURL(url);if(sequence===pickerLoadSequence)$('#picker-result').innerHTML='<p>The image could not be decoded.</p>'};
    image.src=url;
  };
  pickerCanvas.onpointermove=e=>drawLoupe(pickerPoint(e));pickerCanvas.onpointerleave=()=>pickerLoupe.classList.remove('visible');
  pickerCanvas.onclick=e=>{const point=pickerPoint(e);if(!point)return;const size=Number(pickerSampleSize.value),sample=sampleAt(point,size);if(!sample){$('#picker-result').innerHTML='<p>No sufficiently opaque pixels were found in the selected area.</p>';return}const rgb=sample.rgb;let best=null,bestD=Infinity;for(const c of colors){const d=(c.rgb[0]-rgb[0])**2+(c.rgb[1]-rgb[1])**2+(c.rgb[2]-rgb[2])**2;if(d<bestD||(d===bestD&&c.id<best.id)){best=c;bestD=d}}const sourceHex='#'+rgb.map(v=>v.toString(16).padStart(2,'0')).join('').toUpperCase(),mode=size===1?'PIXEL_RGB':'AREA_MEAN_RGB',bounds=sample.bounds.join(' / '),assignment=window.ATLAS_CLARUS_EXPORTS.createSourceAssignment(sample,point,pickerImageMeta,best,MASTER);$('#picker-result').innerHTML=`<p class="eyebrow">${size===1?'PIXEL':'AREA'} RESOLVED</p><div class="pixel-preview" style="background:${sourceHex}"></div><dl><dt>Sampling mode</dt><dd>${mode}</dd><dt>Centre coordinate</dt><dd>${point.ix} / ${point.iy}</dd>${size===1?'':`<dt>Requested area</dt><dd>${size} × ${size} px</dd><dt>Actual bounds</dt><dd>${bounds}</dd><dt>Valid pixels</dt><dd>${sample.count}</dd><dt>Channel σ (diagnostic)</dt><dd>${sample.std.map(v=>v.toFixed(2)).join(' / ')}</dd>`}<dt>${size===1?'Source pixel':'Mean source RGB'}</dt><dd>${rgb.join(' / ')}</dd><dt>Source HEX</dt><dd>${sourceHex}</dd><dt>ATLAS reference</dt><dd>${best.ref}</dd><dt>atlas_row_id</dt><dd>${best.id}</dd><dt>Master RGB</dt><dd>${best.rgb.join(' / ')}</dd><dt>RGB squared distance</dt><dd>${bestD}</dd></dl><button data-picker-hover>Open in Hover</button>`;$('#picker-result [data-picker-hover]').onclick=()=>{pickerReturn=true;select(best,assignment);$('#search').value=best.ref;filter();location.hash='library'};};
  function hcl(c){const m=c.ref.match(/H(\d+)_L(\d+)_C(\d+)/);return m?m.slice(1).map(Number):[0,c.lab[0],0]}
  function hueDistance(a,b){const d=Math.abs(a-b)%360;return Math.min(d,360-d)}
  function nearestHlc(H,L,C,exclude=-1){return colors.reduce((best,c)=>{if(c.id===exclude)return best;const q=hcl(c),d=hueDistance(q[0],H)**2+(q[1]-L)**2*5+(q[2]-C)**2*.8;return !best||d<best.d?{c,d}:best},null).c}
  function renderWheelCards(){if(!selected||!$('#harmony-cards'))return;const [H,L,C]=hcl(selected);$('#contrast-preview').style.background=selected.hex;$('#illumination-card').innerHTML=`<dt>Reference</dt><dd>${selected.ref}</dd><dt>Master Lab</dt><dd>${selected.lab.map(n=>Number(n).toFixed(2)).join(' / ')}</dd><dt>Recorded status</dt><dd>Identity evidence</dd>`;$('#arbe-card').innerHTML=arbeReference?`<p><b>${arbeReference.ref}</b> → <b>${selected.ref}</b></p><dl><dt>ΔH address</dt><dd>${hueDistance(hcl(arbeReference)[0],H).toFixed(0)}°</dd><dt>Identity mutation</dt><dd>NONE</dd></dl>`:'<p>No comparison reference locked.</p>';const rule=$('#harmony-rule').value;const offsets=rule==='analogous'?[-30,30]:rule==='triadic'?[120,240]:[180];const hs=[selected,...offsets.map(o=>nearestHlc((H+o+360)%360,L,C,selected.id))];$('#harmony-cards').innerHTML='';hs.forEach((c,i)=>{const b=document.createElement('button');b.className='mini-card';b.innerHTML=`<i style="background:${c.hex}"></i><b>${i?'Related':'Base'}</b><small>${c.ref}</small>`;b.onclick=()=>select(c);$('#harmony-cards').append(b)});$('#tone-ramp').innerHTML='';for(let l=5;l<=95;l+=10){const c=nearestHlc(H,l,C);const b=document.createElement('button');b.className='tone-button';b.style.background=c.hex;b.innerHTML=`<small>${l}</small>`;b.title=c.ref;b.onclick=()=>select(c);$('#tone-ramp').append(b)}$('#measurement-target').innerHTML=`<span class="eyebrow">ORIGINAL ATLAS IDENTITY</span><h3>${selected.ref}</h3><p>Row ${selected.id} · Master Lab ${selected.lab.map(n=>Number(n).toFixed(2)).join(' / ')}</p><p>Frozen identity remains unchanged.</p>`;renderProfiles();renderPalette()}
  $('#harmony-rule').onchange=renderWheelCards;$('#lock-reference').onclick=()=>{arbeReference=selected;renderWheelCards()};
  const PALETTE_KEY='atlasClarusPalettesV3';
  function uid(){return globalThis.crypto?.randomUUID?.()||`palette-${Date.now()}-${Math.random().toString(16).slice(2)}`}
  function currentPalette(){return palettes.find(p=>p.id===activePaletteId)||palettes[0]}
  function syncPalette(){const p=currentPalette();activePaletteId=p.id;palette=p.colorIds.map(id=>colors.find(c=>c.id===id)).filter(Boolean).slice(0,64);p.colorIds=palette.map(c=>c.id)}
  function loadPalettes(){
    try{
      const current=localStorage.getItem(PALETTE_KEY);
      const state=JSON.parse(current||localStorage.getItem('atlasClarusPalettesV2')||'null');
      if(state){
        if(![2,3].includes(state.version)||!Array.isArray(state.palettes)||!state.palettes.length||state.palettes.length>50)throw Error('Invalid workspace.');
        if(state.version===3&&(state.master_sha256!==MASTER||state.workflow!==window.ATLAS_CLARUS_EXPORTS.WORKFLOW))throw Error('Workspace master mismatch.');
        const seen=new Set();
        const restored=state.palettes.map(p=>{
          if(!p||typeof p.id!=='string'||seen.has(p.id)||typeof p.name!=='string'||!Array.isArray(p.colorIds)||p.colorIds.length>64||new Set(p.colorIds).size!==p.colorIds.length||p.colorIds.some(id=>!Number.isInteger(id)||!colors.some(c=>c.id===id)))throw Error('Invalid saved palette.');
          seen.add(p.id);
          const records=state.version===3?p.sourceAssignments:[];
          if(state.version===2&&p.sourceAssignments!==undefined)throw Error('Unexpected legacy source records.');
          const sourceAssignments=window.ATLAS_CLARUS_EXPORTS.validateSourceAssignments(records,colors,MASTER,p.colorIds);
          return {id:p.id,name:p.name.trim().slice(0,60)||'Untitled palette',colorIds:[...p.colorIds],sourceAssignments};
        });
        palettes=restored;activePaletteId=palettes.some(p=>p.id===state.activeId)?state.activeId:palettes[0].id;
      }
    }catch(_){const warning=$('#palette-storage-status');warning.textContent='Saved palettes or source records could not be verified. Import a Clarus JSON backup to restore your references. Export your work before leaving this page.';warning.hidden=false}
    if(!palettes.length){
      let legacy=[];try{legacy=JSON.parse(localStorage.getItem('atlasClarusSharedPaletteV1')||'[]').filter(id=>Number.isInteger(id)&&colors.some(c=>c.id===id)).slice(0,64)}catch(_){}
      const p={id:uid(),name:'My first palette',colorIds:[...new Set(legacy)],sourceAssignments:[]};palettes=[p];activePaletteId=p.id;
    }
    syncPalette();
  }
  function persistPalettes(){
    const p=currentPalette();p.colorIds=palette.map(c=>c.id);
    p.sourceAssignments=(p.sourceAssignments||[]).filter(r=>p.colorIds.includes(r.atlas_row_id));
    const warning=$('#palette-storage-status');
    try{
      localStorage.setItem(PALETTE_KEY,JSON.stringify({version:3,master_sha256:MASTER,workflow:window.ATLAS_CLARUS_EXPORTS.WORKFLOW,activeId:activePaletteId,palettes}));
      warning.hidden=true;warning.textContent='';
    }catch(_){
      warning.textContent='Your latest palette changes could not be saved in this browser. Keep this page open and export each changed palette as Clarus JSON before leaving.';
      warning.hidden=false;
    }
    renderPalette();
  }
  function paletteStatus(message,error=false){const el=$('#export-status');el.textContent=message;el.style.color=error?'#ff8f8f':''}
  function addPalette(c,assignment=selectedAssignment){
    $('#palette-drawer').classList.add('open');
    const p=currentPalette(),exists=palette.some(x=>x.id===c.id);
    if(!exists&&palette.length>=64){paletteStatus('This palette holds 64 colours. Create or select another palette to add more.',true);return}
    const records=p.sourceAssignments||[];
    let addedSource=false,nextRecords=records;
    if(assignment){
      try{
        const [verified]=window.ATLAS_CLARUS_EXPORTS.validateSourceAssignments([assignment],colors,MASTER,[c.id]);
        if(!records.some(r=>JSON.stringify(r)===JSON.stringify(verified))){
          if(records.length>=window.ATLAS_CLARUS_EXPORTS.MAX_SOURCE_ASSIGNMENTS)throw Error('This palette holds 4096 source records. Create another palette to preserve further samples.');
          nextRecords=[...records,verified];addedSource=true;
        }
      }catch(err){paletteStatus(`Source record not added: ${err.message}`,true);return}
    }
    if(exists&&!addedSource){paletteStatus('This reference and any selected source record are already in the active palette.');return}
    p.sourceAssignments=nextRecords;
    if(!exists)palette.push(c);
    persistPalettes();paletteStatus(`Added ${addedSource?'source assignment for ':''}${c.ref}. Export Clarus JSON to keep a portable backup.`);
  }
  function canCreatePalette(){
    if(palettes.length<50)return true;
    paletteStatus('This workspace holds 50 palettes. Export a backup before removing a palette to make room.',true);return false;
  }
  function movePaletteColour(from,to){if(to<0||to>=palette.length||from===to)return;const [c]=palette.splice(from,1);palette.splice(to,0,c);persistPalettes()}
  function renderPalette(){const box=$('#palette-list'),drawer=$('#drawer-palette-list'),selectBox=$('#palette-select'),p=currentPalette();if(box){box.innerHTML=palette.length?'':'<p class="boundary">No identities added yet.</p>';palette.forEach(c=>{const b=document.createElement('button');b.className='palette-chip';b.innerHTML=`<i style="background:${c.hex}"></i><b>${c.ref}</b>`;b.onclick=()=>select(c);box.append(b)})}$('#palette-count').textContent=palette.length;selectBox.innerHTML='';palettes.forEach(x=>{const o=document.createElement('option');o.value=x.id;o.textContent=`${x.name} (${x.colorIds.length})`;o.selected=x.id===activePaletteId;selectBox.append(o)});$('#palette-name').value=p.name;drawer.innerHTML=palette.length?'':'<p class="boundary">Select a colour in the Hover Library and choose “Add to palette”.</p>';palette.forEach((c,index)=>{const row=document.createElement('div');row.className='drawer-item';row.draggable=true;row.dataset.index=index;row.innerHTML=`<i style="background:${c.hex}"></i><span><b>${c.ref}</b><small>${c.hex} · row ${c.id}</small></span><div class="drawer-item-actions"><button data-up aria-label="Move ${c.ref} up">↑</button><button data-down aria-label="Move ${c.ref} down">↓</button><button data-remove aria-label="Remove ${c.ref}">×</button></div>${paletteSourcesHtml(c,p)}`;row.querySelector('span').onclick=()=>{select(c);location.hash='wheel'};row.querySelector('[data-up]').onclick=()=>movePaletteColour(index,index-1);row.querySelector('[data-down]').onclick=()=>movePaletteColour(index,index+1);row.querySelector('[data-remove]').onclick=()=>{palette.splice(index,1);persistPalettes()};row.ondragstart=e=>{row.classList.add('dragging');e.dataTransfer.setData('text/plain',String(index));e.dataTransfer.effectAllowed='move'};row.ondragend=()=>row.classList.remove('dragging');row.ondragover=e=>e.preventDefault();row.ondrop=e=>{e.preventDefault();movePaletteColour(Number(e.dataTransfer.getData('text/plain')),index)};drawer.append(row)})}
  loadPalettes();renderPalette();
  $('#palette-select').onchange=()=>{activePaletteId=$('#palette-select').value;syncPalette();persistPalettes()};
  $('#palette-new').onclick=()=>{if(!canCreatePalette())return;const p={id:uid(),name:`Palette ${palettes.length+1}`,colorIds:[],sourceAssignments:[]};palettes.push(p);activePaletteId=p.id;syncPalette();persistPalettes();$('#palette-name').focus();$('#palette-name').select()};
  $('#palette-rename').onclick=()=>{const name=$('#palette-name').value.trim().slice(0,60);if(!name){paletteStatus('Enter a palette name.',true);return}currentPalette().name=name;persistPalettes();paletteStatus(`Renamed to “${name}”.`)};
  $('#palette-duplicate').onclick=()=>{if(!canCreatePalette())return;const source=currentPalette(),p={id:uid(),name:`${source.name} copy`.slice(0,60),colorIds:[...source.colorIds],sourceAssignments:JSON.parse(JSON.stringify(source.sourceAssignments||[]))};palettes.push(p);activePaletteId=p.id;syncPalette();persistPalettes();paletteStatus('Palette duplicated.')};
  $('#palette-delete').onclick=()=>{if(palettes.length===1){palette=[];currentPalette().name='My first palette';persistPalettes();paletteStatus('The only palette was reset.');return}const old=currentPalette().name,index=palettes.findIndex(p=>p.id===activePaletteId);palettes.splice(index,1);activePaletteId=palettes[Math.max(0,index-1)].id;syncPalette();persistPalettes();paletteStatus(`Deleted “${old}”.`)};
  $('#palette-import').onclick=()=>$('#palette-import-file').click();$('#palette-import-file').onchange=async e=>{const file=e.target.files[0];e.target.value='';if(!file)return;try{const data=JSON.parse(await file.text());const restored=window.ATLAS_CLARUS_EXPORTS.parseClarus(data,colors,MASTER),ids=restored.colorIds;if(!canCreatePalette())return;const p={id:uid(),name:String(data.palette_name||file.name.replace(/\.clarus\.json$|\.json$/i,'')||'Imported palette').trim().slice(0,60)||'Imported palette',colorIds:ids,sourceAssignments:restored.sourceAssignments};palettes.push(p);activePaletteId=p.id;syncPalette();persistPalettes();paletteStatus(`Imported ${ids.length} verified identities and ${restored.sourceAssignments.length} source records.`)}catch(err){paletteStatus(`Import blocked: ${err.message}`,true)}};
  $('#add-palette').onclick=()=>addPalette(selected);$('#clear-palette').onclick=$('#drawer-clear').onclick=()=>{palette=[];persistPalettes()};$('#export-palette').onclick=()=>exportPalette('clarus');$('#palette-toggle').onclick=()=>$('#palette-drawer').classList.add('open');$('#palette-close').onclick=()=>$('#palette-drawer').classList.remove('open');
  function download(name,data,type){const a=document.createElement('a'),blob=data instanceof Uint8Array?new Blob([data],{type}):new Blob([data],{type});a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1200)}
  function exportPalette(kind){const E=window.ATLAS_CLARUS_EXPORTS,p=currentPalette(),name=p.name,stem=name.replace(/[^a-z0-9_-]+/gi,'_').replace(/^_+|_+$/g,'')||'ATLAS_Clarus_Palette';if(!palette.length){paletteStatus('Add at least one colour before exporting.',true);return}if(kind==='ase'){const bytes=E.ase(palette),back=E.readAse(bytes),ok=back.length===palette.length&&back.every((x,i)=>x.ref===palette[i].ref&&x.rgb.every((v,j)=>v===palette[i].rgb[j]));if(!ok){paletteStatus('ASE readback failed. Export blocked.',true);return}download(`${stem}.ase`,bytes,'application/octet-stream');paletteStatus(`ASE exported and read back: ${palette.length} exact RGB swatches.`)}else if(kind==='tokens'){download(`${stem}.tokens.json`,JSON.stringify(E.tokens(palette,MASTER,name),null,2),'application/json');paletteStatus('Figma-compatible Design Tokens exported.')}else if(kind==='css'){download(`${stem}.css`,E.css(palette,MASTER,name),'text/css');paletteStatus('CSS custom properties exported.')}else if(kind==='gpl'){download(`${stem}.gpl`,E.gpl(palette,MASTER,name),'text/plain');paletteStatus('GIMP / Inkscape GPL palette exported.')}else{try{const data=E.clarus(palette,MASTER,name,p.sourceAssignments||[]);E.parseClarus(data,colors,MASTER);download(`${stem}.clarus.json`,JSON.stringify(data,null,2),'application/json');paletteStatus('Clarus identities and original source assignments exported.')}catch(err){paletteStatus(`Export blocked: ${err.message}`,true)}}}
  document.querySelectorAll('[data-palette-export]').forEach(b=>b.onclick=()=>exportPalette(b.dataset.paletteExport));
  function renderProfiles(){const specs=[['sRGB','ACTIVE OUTPUT',selected.hex],['Display P3','COMPARISON',`linear-gradient(135deg,${selected.hex},#111)`],['Adobe RGB','COMPARISON',`linear-gradient(135deg,#111,${selected.hex})`],['FOGRA55 CMYKOGV','FEASIBILITY ONLY','linear-gradient(135deg,#00a9ce,#ec008c 34%,#fff200 67%,#171717)']];$('#profile-cards').innerHTML=specs.map(x=>`<article class="profile-card"><i style="background:${x[2]}"></i><div><span>${x[1]}</span><h4>${x[0]}</h4><small>${x[0]==='sRGB'?'Bound screen representation':'Profile transform not bound in offline bundle'}</small></div></article>`).join('')}
  $('#bind-measurement').onclick=()=>{const v=['measured-l','measured-a','measured-b'].map(id=>Number($('#'+id).value)),inst=$('#instrument').value.trim();if(v.some(x=>!Number.isFinite(x))||!inst){$('#measurement-result').textContent='Enter all three Lab values and the measurement source.';return}const d=Math.sqrt(v.reduce((s,x,i)=>s+(x-selected.lab[i])**2,0));$('#measurement-result').innerHTML=`Entered result appended locally for review: <b>ΔE*ab ${d.toFixed(3)}</b> · source ${esc(inst)}. This is not ΔE00 and is not stored in the master.`};
  function drawWheel(){const cv=$('#wheel-canvas');if(!cv)return;const ctx=cv.getContext('2d');const w=cv.width,h=cv.height,cx=w/2,cy=h/2,R=w*.43;ctx.clearRect(0,0,w,h);const grad=ctx.createRadialGradient(cx,cy,25,cx,cy,R);grad.addColorStop(0,'#e8e5df');grad.addColorStop(.45,'#75777b');grad.addColorStop(1,'#171c23');ctx.fillStyle=grad;ctx.beginPath();ctx.arc(cx,cy,R,0,Math.PI*2);ctx.fill();const [sh,sl,sc]=hcl(selected);const layer=colors.filter(c=>Math.abs(hcl(c)[1]-sl)<2.6);layer.forEach(c=>{const [H,,C]=hcl(c);const a=(H-90)*Math.PI/180;const r=Math.min(R,C/105*R);ctx.fillStyle=c.hex;ctx.beginPath();ctx.arc(cx+Math.cos(a)*r,cy+Math.sin(a)*r,3.2,0,Math.PI*2);ctx.fill()});const a=(sh-90)*Math.PI/180,r=Math.min(R,sc/105*R);ctx.strokeStyle='#fff';ctx.lineWidth=4;ctx.beginPath();ctx.arc(cx+Math.cos(a)*r,cy+Math.sin(a)*r,10,0,Math.PI*2);ctx.stroke();ctx.fillStyle='#fff';ctx.font='18px system-ui';ctx.textAlign='center';ctx.fillText(`L* ${sl}`,cx,cy+6)}
  const mats={paper:[.98,.97,.94],polymer:[1.02,1.02,1.03],metal:[.78,.82,.86],textile:[.86,.84,.81],glass:[.8,.9,1],wood:[.92,.78,.62]};
  function drawSimulation(){const cv=$('#sim-canvas');if(!cv||!selected)return;const ctx=cv.getContext('2d'),w=cv.width,h=cv.height;const mat=$('#material').value,fin=$('#finish').value,ill=$('#illuminant').value,angle=Number($('#angle').value),depth=Number($('#depth').value)/100;$('#angle-output').value=angle+'°';const light=ill==='A'?[1.16,.88,.62]:ill==='D65'?[.93,.98,1.1]:[1.04,1,.92];const base=selected.rgb.map((v,i)=>v*mats[mat][i]*light[i]);const img=ctx.createImageData(w,h);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const p=(y*w+x)*4,n=Math.sin(x*.14)+Math.cos(y*.17)+Math.sin((x+y)*.037),glint=Math.pow(Math.max(0,1-Math.abs(x/w-(.25+angle/160))),fin==='gloss'?18:fin==='metallic'?7:40)*(fin==='gloss'?90:fin==='metallic'?120:25);for(let i=0;i<3;i++)img.data[p+i]=Math.max(0,Math.min(255,base[i]*(1+n*depth*.075)+glint));img.data[p+3]=255}ctx.putImageData(img,0,0);ctx.fillStyle='#000b';ctx.fillRect(20,h-85,520,62);ctx.fillStyle='#fff';ctx.font='bold 22px system-ui';ctx.fillText(selected.ref,38,h-52);ctx.font='15px system-ui';ctx.fillStyle='#cbd5e1';ctx.fillText(`${mat} · ${fin} · ${ill} · ${angle}° · simulated screen appearance`,38,h-28);$('#sim-caption').textContent=`Frozen source: ${selected.ref} · ${selected.hex}. Appearance layer: simulated. measured_qc_status = NOT_MEASURED.`}
  ['material','finish','illuminant','angle','depth'].forEach(id=>$('#'+id).oninput=drawSimulation);
  const workflows=[
    {name:'Inkscape',version:'v0.3.0',status:'WORKING REFERENCE HANDOFF',can:'Select an SVG fill or stroke, match it to the full ATLAS master, and write the frozen reference back with an audit record.',verified:'Direct fill, stroke and CSS handoff were validated for the documented extension version.',next:'Install and test the extension in the user’s own Inkscape environment before production use.',steps:['Choose SVG colour','Match full master','Freeze identity','Write colour','Review audit']},
    {name:'GIMP',version:'v0.1.3',status:'ENGINEERING BETA',can:'Select an 8-bit sRGB image pixel and bind it deterministically to one ATLAS reference identity.',verified:'The documented pixel-to-reference example and frozen source identity passed the engineering checks.',next:'Broader runtime and image-workflow testing is still required. This is not an image-wide physical proof.',steps:['Choose pixel','Read sRGB','Match full master','Freeze identity','Document result']},
    {name:'Krita',version:'v0.3.4',status:'RUNTIME TEST REQUIRED',can:'Search the full master from a Krita document colour and retain the selected ATLAS identity.',verified:'The plugin package and identity boundary are documented.',next:'The current package must still pass the stated installation and full-master UI runtime gate in Krita.',steps:['Choose colour','Search master','Select reference','Freeze row ID','Run audit']},
    {name:'Scribus',version:'PLANNED MVP',status:'NOT YET A FINISHED INTEGRATION',can:'The planned proof will carry one frozen identity into a separate print-production workflow.',verified:'Only the architecture and separation of identity from production mapping are currently documented.',next:'Bind a real ICC profile, generate and inspect PDF/X, then compare a measured physical print. No print result is currently verified.',steps:['Frozen identity','Check feasibility','Create device values','Inspect PDF/X','Measure print later']}
  ];
  function showWorkflow(i){const w=workflows[i];$('#workflow-detail').innerHTML=`<div class="connection-title"><div><p class="eyebrow">${esc(w.version)}</p><h3>ATLAS Clarus × ${esc(w.name)}</h3></div><span class="connection-status">${esc(w.status)}</span></div><div class="connection-explain"><article><span>WHAT YOU CAN DO</span><p>${esc(w.can)}</p></article><article><span>WHAT IS VERIFIED</span><p>${esc(w.verified)}</p></article><article><span>WHAT IS STILL NEEDED</span><p>${esc(w.next)}</p></article></div><h4 class="flow-label">The handoff in five steps</h4><div class="steps">${w.steps.map((s,n)=>`<div class="step"><strong>0${n+1}</strong>${esc(s)}</div>`).join('')}</div><p class="boundary"><b>Identity rule:</b> The PKL Full Reference remains authoritative. Application and production values may be appended, but they cannot redefine the frozen source identity.</p>`}
  workflows.forEach((w,i)=>{const b=document.createElement('button');b.className='workflow-card';b.innerHTML=`<b>${esc(w.name)}</b><span>${esc(w.version)}</span><em>${esc(w.status)}</em>`;b.onclick=()=>showWorkflow(i);$('#workflow-cards').append(b)});
  if(doc.master_sha256!==MASTER||colors.length!==13283||!libraryViews.core||libraryViews.core.ids.length!==13283){document.body.innerHTML='<main class="view active"><h1>Bundle validation failed</h1><p>The embedded master metadata, reference count or library views do not match the release baseline.</p></main>';return}
  referenceCardWorkspace=window.ATLAS_CLARUS_REFERENCE_CARD?.init({colors,master:MASTER,designerLayer,download});
  printWorkspace=window.ATLAS_CLARUS_PRINT_UI?.init({colors,master:MASTER,getSelected:()=>selected,getPalette:()=>palette,getPaletteName:()=>currentPalette().name,getPickerImage:()=>pickerImage?{canvas:pickerSource,name:pickerFileName}:null,download});
  document.querySelectorAll('[data-print-palette]').forEach(b=>b.onclick=()=>printWorkspace?.open('palette'));
  window.ATLAS_COLOUR_HANDOFF_UI.init({colors,master:MASTER,getBundle:()=>window.ATLAS_CLARUS_EXPORTS.clarus(palette,MASTER,currentPalette().name,currentPalette().sourceAssignments||[]),download});
  window.ATLAS_COLOUR_PROJECTS_UI.init({colors,master:MASTER,download});
  select(selected);render();showWorkflow(0);route();
})();
