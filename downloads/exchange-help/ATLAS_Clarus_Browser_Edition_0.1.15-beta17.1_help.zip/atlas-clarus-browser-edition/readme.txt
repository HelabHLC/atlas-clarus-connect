ATLAS Clarus Browser Edition 0.1.15-beta17
RC33.8 public beta: RGB only, default 32 colours, result-region correction, both protection modes and RGB deviation map.
Updating the plugin preserves the current runtime. Then use Tools > ATLAS Clarus Browser Edition to verify and activate the embedded RC33.8. Previous runtime retained for rollback. Export open projects before updating; no autosave.
