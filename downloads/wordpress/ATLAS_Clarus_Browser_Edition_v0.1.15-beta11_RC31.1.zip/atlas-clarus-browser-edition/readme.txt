ATLAS Clarus Browser Edition 0.1.15-beta11
RC31.1 Image Projects: recolour, make transparent, undo/redo with retained history.
Upload this ZIP without extracting it and replace ATLAS Clarus Browser Edition.
Then open Tools > ATLAS Clarus Browser Edition and select:
Mitgeliefertes RC31.1 prüfen und aktiv schalten
The plugin update alone keeps the currently served runtime. The guarded switch
keeps the previous runtime for rollback. Other ATLAS plugins are not replaced.

Open Colour Projects > Open Image Projects. PNG/JPEG up to 8 MiB / 4,194,304 pixels.
Click a colour or drag a rectangle. Recolour or make transparent with a note.
Undo and redo retain all earlier steps. Download the complete ZIP or image-project
JSON before closing the tab. A colleague can reopen either file and continue.
The JSON embeds the original file, frozen sRGB pixels and exact changed-pixel masks.
Existing Colour Projects palettes remain separate and can be attached as snapshots.
Live IONOS activation, native Adobe round trips and physical output: NOT_TESTED.
