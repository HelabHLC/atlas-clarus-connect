ATLAS Clarus Browser Edition 0.1.15-beta10
RC30.1 Colour Projects WordPress update, requested by the owner on 2026-10-09.

INSTALL THIS ZIP WITHOUT EXTRACTING IT through Plugins > Add New > Upload Plugin.
Replace the existing ATLAS Clarus Browser Edition; do not delete it first.
Then open Tools > ATLAS Clarus Browser Edition and select:
Mitgeliefertes RC30.1 prüfen und aktiv schalten
The plugin update alone keeps the currently served runtime. The explicit switch
validates the new runtime and keeps the previous one for rollback.

Full project JSON retains source palettes, decisions and project history.
Handover ZIPs add working/chosen ASE swatches with their provenance companions.
Each visitor's project data remain local to their browser; download backups.
Native Adobe application round trips and live IONOS acceptance: NOT_TESTED.
