ATLAS Clarus Browser Edition 0.1.15-beta12
RC32.1 Colour Reference Card public pilot.
Upload this ZIP without extracting it and replace ATLAS Clarus Browser Edition.
Then open Tools > ATLAS Clarus Browser Edition and select:
Mitgeliefertes RC32.1 prüfen und aktiv schalten
The plugin update alone preserves the active runtime. The guarded switch keeps
that runtime for rollback. Existing public URLs and shortcodes remain unchanged.

Open Colour Handoff, import decision JSON or use a palette snapshot, then choose
Download colour reference card ZIP. Open the HTML and use Print / Save as PDF.
Keep palette.clarus.json, reference-card.json and card-manifest.json together.
Original source RGB/HEX, reference RGB/HLC/row, master checksum, decision IDs,
revision IDs and available provenance remain distinct. Unknown stays UNKNOWN.
Checksums verify content integrity; they do not authenticate authorship.
Native Adobe, physical output and real-device mobile acceptance: NOT_TESTED.
