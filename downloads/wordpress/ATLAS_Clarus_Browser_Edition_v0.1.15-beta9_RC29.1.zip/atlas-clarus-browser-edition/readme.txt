ATLAS Clarus Browser Edition 0.1.15-beta9
RC29.1 public website pilot, authorized by the owner on 2026-10-08.
Original values, source and decision history travel in the companion JSON.
Native Adobe round trips: NOT_TESTED. Not embedded automatically in Adobe documents.
Update alone preserves the current runtime. Use Tools > ATLAS Clarus Browser Edition
to validate and switch; the previous runtime remains available for rollback.
WordPress 6.9+ also exposes atlas-clarus/install-browser-bundle to authenticated
administrators (manage_options). It accepts only the embedded ZIP SHA-256 and
expected current runtime SHA-256, then runs the same guarded installer.
No arbitrary URL, path or executable code is accepted by this ability.
